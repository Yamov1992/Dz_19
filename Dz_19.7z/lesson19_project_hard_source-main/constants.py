# Добавляем константы в файл constants.py
PWD_HASH_SALT = b'secret here'
PWD_HASH_ITERATIONS = 100_000

JWT_SECRET = "s3cR$Et"
JWT_ALGORITHM = "HS256"